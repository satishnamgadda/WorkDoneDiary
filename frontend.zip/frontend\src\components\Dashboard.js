import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Dashboard = ({ user, onLogout, apiBaseUrl }) => {
  const [activeView, setActiveView] = useState('dashboard');
  const [entries, setEntries] = useState([]);
  const [stats, setStats] = useState({
    totalEntries: 0,
    pendingReviews: 0,
    completionRate: 0
  });
  const [newEntry, setNewEntry] = useState({
    subject: '',
    department: '',
    topic: '',
    content: '',
    syllabus_progress: 0
  });

  const departments = ['Computer Science', 'Electronics', 'Mechanical', 'Civil', 'Electrical'];
  const subjects = ['Programming', 'Database', 'Networks', 'Algorithms', 'Software Engineering'];

  useEffect(() => {
    fetchEntries();
    fetchStats();
  }, []);

  const fetchEntries = async () => {
    try {
      const response = await axios.get(`${apiBaseUrl}/entries/`);
      setEntries(response.data);
    } catch (error) {
      console.error('Failed to fetch entries:', error);
    }
  };

  const fetchStats = async () => {
    try {
      const response = await axios.get(`${apiBaseUrl}/dashboard/stats/`);
      setStats(response.data);
    } catch (error) {
      console.error('Failed to fetch stats:', error);
    }
  };

  const handleAddEntry = async (e) => {
    e.preventDefault();
    try {
      await axios.post(`${apiBaseUrl}/entries/`, newEntry);
      setNewEntry({
        subject: '',
        department: '',
        topic: '',
        content: '',
        syllabus_progress: 0
      });
      fetchEntries();
      fetchStats();
      setActiveView('diary');
    } catch (error) {
      console.error('Failed to add entry:', error);
    }
  };

  const renderDashboard = () => (
    <div>
      <div className="page-header">
        <h1 className="page-title">Dashboard</h1>
        <p className="page-subtitle">Welcome back, {user.name}</p>
      </div>

      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-value">{stats.totalEntries}</div>
          <div className="stat-label">Total Entries</div>
        </div>
        <div className="stat-card">
          <div className="stat-value">{stats.pendingReviews}</div>
          <div className="stat-label">Pending Reviews</div>
        </div>
        <div className="stat-card">
          <div className="stat-value">{stats.completionRate}%</div>
          <div className="stat-label">Completion Rate</div>
        </div>
      </div>

      <div className="content-card">
        <h2 className="card-title">Recent Activity</h2>
        {entries.slice(0, 3).map(entry => (
          <div key={entry.id} className="entry-card">
            <div className="entry-header">
              <span className="entry-subject">{entry.subject}</span>
              <span className="entry-date">{new Date(entry.created_at).toLocaleDateString()}</span>
            </div>
            <div className="entry-content">{entry.topic}</div>
            <div className="progress-bar">
              <div 
                className="progress-fill" 
                style={{ width: `${entry.syllabus_progress}%` }}
              ></div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderAddEntry = () => (
    <div>
      <div className="page-header">
        <h1 className="page-title">Add New Entry</h1>
        <p className="page-subtitle">Record your teaching progress</p>
      </div>

      <div className="content-card">
        <form onSubmit={handleAddEntry}>
          <div className="form-row">
            <div className="form-group">
              <label className="form-label">Department</label>
              <select
                className="form-select"
                value={newEntry.department}
                onChange={(e) => setNewEntry({...newEntry, department: e.target.value})}
                required
              >
                <option value="">Select Department</option>
                {departments.map(dept => (
                  <option key={dept} value={dept}>{dept}</option>
                ))}
              </select>
            </div>
            <div className="form-group">
              <label className="form-label">Subject</label>
              <select
                className="form-select"
                value={newEntry.subject}
                onChange={(e) => setNewEntry({...newEntry, subject: e.target.value})}
                required
              >
                <option value="">Select Subject</option>
                {subjects.map(subject => (
                  <option key={subject} value={subject}>{subject}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="form-group">
            <label className="form-label">Topic</label>
            <input
              type="text"
              className="form-input"
              value={newEntry.topic}
              onChange={(e) => setNewEntry({...newEntry, topic: e.target.value})}
              required
            />
          </div>

          <div className="form-group">
            <label className="form-label">Content</label>
            <textarea
              className="form-input"
              rows="4"
              value={newEntry.content}
              onChange={(e) => setNewEntry({...newEntry, content: e.target.value})}
              required
            ></textarea>
          </div>

          <div className="form-group">
            <label className="form-label">Syllabus Progress (%)</label>
            <input
              type="number"
              className="form-input"
              min="0"
              max="100"
              value={newEntry.syllabus_progress}
              onChange={(e) => setNewEntry({...newEntry, syllabus_progress: parseInt(e.target.value)})}
              required
            />
          </div>

          <button type="submit" className="btn-primary">Add Entry</button>
        </form>
      </div>
    </div>
  );

  const renderDiary = () => (
    <div>
      <div className="page-header">
        <h1 className="page-title">Work Diary</h1>
        <p className="page-subtitle">Your teaching entries</p>
      </div>

      <div className="content-card">
        {entries.map(entry => (
          <div key={entry.id} className="entry-card">
            <div className="entry-header">
              <span className="entry-subject">{entry.subject} - {entry.topic}</span>
              <span className="entry-date">{new Date(entry.created_at).toLocaleDateString()}</span>
            </div>
            <div className="entry-content">{entry.content}</div>
            <div style={{ marginTop: '1rem' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.5rem' }}>
                <span style={{ color: '#9ca3af', fontSize: '0.9rem' }}>Syllabus Progress</span>
                <span style={{ color: '#d4a843', fontSize: '0.9rem' }}>{entry.syllabus_progress}%</span>
              </div>
              <div className="progress-bar">
                <div 
                  className="progress-fill" 
                  style={{ width: `${entry.syllabus_progress}%` }}
                ></div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <div className="dashboard">
      <div className="sidebar">
        <div className="sidebar-header">
          <h2 className="sidebar-title">College Diary</h2>
          <div className="user-info">
            <div>{user.name}</div>
            <div className="role-badge">{user.role}</div>
          </div>
        </div>

        <ul className="nav-menu">
          <li className="nav-item">
            <a 
              href="#" 
              className={`nav-link ${activeView === 'dashboard' ? 'active' : ''}`}
              onClick={() => setActiveView('dashboard')}
            >
              Dashboard
            </a>
          </li>
          <li className="nav-item">
            <a 
              href="#" 
              className={`nav-link ${activeView === 'add-entry' ? 'active' : ''}`}
              onClick={() => setActiveView('add-entry')}
            >
              Add Entry
            </a>
          </li>
          <li className="nav-item">
            <a 
              href="#" 
              className={`nav-link ${activeView === 'diary' ? 'active' : ''}`}
              onClick={() => setActiveView('diary')}
            >
              Work Diary
            </a>
          </li>
        </ul>

        <button className="logout-btn" onClick={onLogout}>
          Logout
        </button>
      </div>

      <div className="main-content">
        {activeView === 'dashboard' && renderDashboard()}
        {activeView === 'add-entry' && renderAddEntry()}
        {activeView === 'diary' && renderDiary()}
      </div>
    </div>
  );
};

export default Dashboard;